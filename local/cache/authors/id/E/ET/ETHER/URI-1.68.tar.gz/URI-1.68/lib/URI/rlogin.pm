package URI::rlogin;

use strict;
use warnings;

use parent 'URI::_login';

sub default_port { 513 }

1;
