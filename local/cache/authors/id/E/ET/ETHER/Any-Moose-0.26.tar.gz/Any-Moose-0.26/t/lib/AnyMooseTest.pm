package AnyMooseTest;
use Any::Moose;

has an_attribute => (
    is => 'ro',
);

1;

