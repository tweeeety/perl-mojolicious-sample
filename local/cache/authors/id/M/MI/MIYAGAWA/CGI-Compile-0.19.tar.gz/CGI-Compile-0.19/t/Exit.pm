package Exit;
sub main { exit }

1;
