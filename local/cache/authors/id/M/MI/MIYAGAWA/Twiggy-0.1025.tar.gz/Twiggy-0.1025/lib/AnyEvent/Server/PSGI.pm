package AnyEvent::Server::PSGI;
use parent 'Twiggy::Server';

1;
