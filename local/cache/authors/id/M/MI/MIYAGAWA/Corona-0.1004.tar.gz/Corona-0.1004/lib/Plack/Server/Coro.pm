package Plack::Server::Coro;
use base qw(Plack::Handler::Corona);

our $VERSION = '0.1002';

1;
