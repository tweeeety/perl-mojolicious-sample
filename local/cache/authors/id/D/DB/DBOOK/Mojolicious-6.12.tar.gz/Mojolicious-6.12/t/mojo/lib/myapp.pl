use Mojolicious::Lite;

app->config(script => $0);

app->start;
